<?php
$host    ="localhost";
$username="webhozztraining_portalrahma";
$password="portalrahma";
$database="webhozztraining_portalrahma";

$conn=mysqli_connect($host,$username,$password,$database);
?>