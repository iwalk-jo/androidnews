<?php 
$host     = "localhost";
$username = "root";
$password = "";
$database = "db_form";

$conn=mysqli_connect($host,$username,$password,$database);
?>